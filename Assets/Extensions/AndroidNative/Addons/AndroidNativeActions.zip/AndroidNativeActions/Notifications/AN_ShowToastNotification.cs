﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("Android Native - Notifications")]
	public class AN_ShowToastNotification : FsmStateAction {

		public FsmString message;


				
		public override void OnEnter() {
			AndroidNotificationManager.instance.ShowToastNotification(message.Value);
			Finish ();
		}
	}
}
