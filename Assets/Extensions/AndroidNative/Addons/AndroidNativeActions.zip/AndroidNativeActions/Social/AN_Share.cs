﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Social")]
	public class AN_Share : FsmStateAction {
				
		public FsmString title;
		public FsmString message;
		public FsmTexture texture;


		public override void OnEnter() {
		
			if (texture.Value != null) {
				AndroidSocialGate.StartShareIntent(title.Value, message.Value, (Texture2D) texture.Value);
			} else {
				AndroidSocialGate.StartShareIntent(title.Value, message.Value);
			}

			Finish();
		}

	}
}


