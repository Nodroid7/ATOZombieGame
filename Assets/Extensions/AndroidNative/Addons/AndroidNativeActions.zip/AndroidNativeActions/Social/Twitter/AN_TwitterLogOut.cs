using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Social")]
	public class AN_TwitterLogOut : FsmStateAction {

		public override void OnEnter() {
			AndroidTwitterManager.instance.LogOut();
			Finish();
		}

	}
}


