﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("Android Native - PlayService")]
	public class AN_LoadAchievements : FsmStateAction {
		
		public FsmEvent successEvent;
		
		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if (IsInEdditorMode) {
				Fsm.Event (successEvent);
				Finish ();
				return;
			}
						
			GooglePlayManager.ActionAchievementsLoaded += OnAchivmentsLoaded;
			GooglePlayManager.instance.LoadAchievements ();
		}
		
		private void OnAchivmentsLoaded(GooglePlayResult r) {
			GooglePlayManager.ActionAchievementsLoaded -= OnAchivmentsLoaded;
			
			Fsm.Event(successEvent);
			Finish();
		}		
	}
}
